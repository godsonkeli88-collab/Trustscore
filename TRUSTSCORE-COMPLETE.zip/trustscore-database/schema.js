// ═══════════════════════════════════════════════════════════
//  TrustScore — MongoDB Database Schema Reference
//  File: database/schema.js
//
//  This file documents:
//   1. Collections & field definitions
//   2. Indexes for performance
//   3. Seed script for development
//   4. Aggregation pipelines for analytics
// ═══════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────
//  COLLECTION: users
// ─────────────────────────────────────────────────────────
/*
{
  _id:            ObjectId,
  name:           String (required, max 100),
  username:       String (required, unique, lowercase, /^[a-z0-9._-]{3,30}$/),
  email:          String (required, unique, lowercase),
  phone:          String,
  password:       String (hashed, bcrypt, select: false),

  // Profile
  title:          String (max 100),
  occupation:     String,
  location:       String,
  bio:            String (max 500),
  skills:         [String],
  avatar:         String | null,          // URL to image (local or Cloudinary)
  avatarInitials: String (max 3),         // Auto-generated from name
  avatarColor:    String (hex),

  // Verification
  verified:       "phone" | "standard" | "advanced",
  verifyLevel:    Number (1–3),
  emailVerified:  Boolean,
  phoneVerified:  Boolean,
  idVerified:     Boolean,

  // TrustScore
  trustScore:     Number (0–100),
  scoreBreakdown: {
    reliability:   Number,
    quality:       Number,
    communication: Number,
    ethics:        Number,
    timeliness:    Number,
  },

  // Activity
  deals:          Number,
  responseRate:   Number (0–100),
  profileViews:   Number,
  badges:         [String],
  premium:        Boolean,
  role:           "user" | "admin",
  suspended:      Boolean,

  // Reviews (embedded)
  reviews: [{
    _id:          ObjectId,
    author:       ObjectId → users,
    authorName:   String,
    authorAvatar: String,
    rating:       Number (1–5),
    text:         String (max 1000),
    category:     String (enum),
    date:         Date,
    verified:     Boolean,
    flagged:      Boolean,
    createdAt:    Date,
    updatedAt:    Date,
  }],

  // Auth tokens (select: false)
  otpCode:        String,
  otpExpiry:      Date,
  resetToken:     String,
  resetExpiry:    Date,

  joinDate:       String,
  createdAt:      Date,
  updatedAt:      Date,
}
*/

// ─────────────────────────────────────────────────────────
//  COLLECTION: reports
// ─────────────────────────────────────────────────────────
/*
{
  _id:          ObjectId,
  reporter:     ObjectId → users (required),
  reporterName: String,
  target:       String (username or name, required),
  targetUser:   ObjectId → users (optional),
  type:         "Scam/Fraud" | "Fake Review" | "Impersonation" |
                "Abuse/Harassment" | "Suspicious Activity" | "Other",
  detail:       String (max 2000, required),
  status:       "pending" | "reviewing" | "resolved" | "dismissed",
  adminNote:    String,
  resolvedBy:   ObjectId → users,
  resolvedAt:   Date,
  createdAt:    Date,
  updatedAt:    Date,
}
*/

// ─────────────────────────────────────────────────────────
//  INDEXES
// ─────────────────────────────────────────────────────────
const mongoose = require("mongoose");

async function createIndexes(db) {
  // users collection
  await db.collection("users").createIndexes([
    { key: { username:   1 }, unique: true },
    { key: { email:      1 }, unique: true },
    { key: { trustScore: -1 } },
    { key: { occupation: 1 } },
    { key: { location:   1 } },
    { key: { verified:   1 } },
    { key: { suspended:  1 } },
    { key: { createdAt:  -1 } },
    // Full-text search
    { key: { name: "text", username: "text", occupation: "text", location: "text", bio: "text" },
      weights: { name: 10, username: 8, occupation: 5, location: 3, bio: 1 },
      name: "user_text_search" },
  ]);

  // reports collection
  await db.collection("reports").createIndexes([
    { key: { reporter: 1 } },
    { key: { status:   1 } },
    { key: { createdAt: -1 } },
  ]);

  console.log("✅  Indexes created");
}

// ─────────────────────────────────────────────────────────
//  SEED DATA — Development only
// ─────────────────────────────────────────────────────────
const seedUsers = [
  {
    name: "Adeola Bello",
    username: "adeola.bello",
    email: "adeola@example.com",
    password: "Password123!",
    phone: "+2348001234567",
    title: "Freelance UX Designer",
    occupation: "Designer",
    location: "Lagos, Nigeria",
    bio: "I craft digital experiences that actually work for people. 8 years in product design.",
    skills: ["Figma","UX Research","Prototyping","Design Systems"],
    avatarColor: "#2a7a6e",
    verified: "advanced",
    verifyLevel: 3,
    trustScore: 94,
    premium: true,
    badges: ["Top Rated","Fast Responder","5-Star Streak","Verified ID"],
    deals: 47,
    responseRate: 98,
    scoreBreakdown: { reliability:97, quality:93, communication:91, ethics:95, timeliness:96 },
    role: "admin",
  },
  {
    name: "Tunde Okafor",
    username: "tunde.okafor",
    email: "tunde@example.com",
    password: "Password123!",
    phone: "+2348001234568",
    title: "Full-Stack Engineer",
    occupation: "Developer",
    location: "Abuja, Nigeria",
    bio: "Node.js and React specialist. Obsessed with performance and clean architecture.",
    skills: ["React","Node.js","PostgreSQL","AWS"],
    avatarColor: "#8b4513",
    verified: "standard",
    verifyLevel: 2,
    trustScore: 88,
    premium: false,
    badges: ["Verified Dev","Code Reviewed","Reliable Worker"],
    deals: 31,
    responseRate: 85,
    scoreBreakdown: { reliability:90, quality:89, communication:85, ethics:88, timeliness:82 },
  },
  {
    name: "Fatima Al-Rashid",
    username: "fatima.alrashid",
    email: "fatima@example.com",
    password: "Password123!",
    phone: "+2348001234569",
    title: "Business Consultant",
    occupation: "Consultant",
    location: "Kano, Nigeria",
    bio: "Helping SMEs scale with strategy, systems, and clarity.",
    skills: ["Strategy","Finance","Marketing","Operations"],
    avatarColor: "#6d4c8e",
    verified: "advanced",
    verifyLevel: 3,
    trustScore: 91,
    premium: true,
    badges: ["Trusted Seller","Top Rated","Verified ID"],
    deals: 62,
    responseRate: 94,
    scoreBreakdown: { reliability:93, quality:90, communication:96, ethics:94, timeliness:89 },
  },
];

async function seed() {
  require("dotenv").config({ path: require("path").join(__dirname, "../backend/.env") });
  await mongoose.connect(process.env.MONGODB_URI);
  const User = require("../backend/src/models/User");

  console.log("🌱 Seeding database...");
  await User.deleteMany({});

  for (const data of seedUsers) {
    const user = new User(data);
    await user.save();
    console.log(`  ✓ Created user: ${user.username}`);
  }

  console.log("\n✅  Seed complete");
  process.exit(0);
}

// ─────────────────────────────────────────────────────────
//  ANALYTICS PIPELINES
// ─────────────────────────────────────────────────────────
const pipelines = {

  // Average TrustScore across all users
  avgTrustScore: [
    { $match: { suspended: false } },
    { $group: { _id: null, avg: { $avg: "$trustScore" }, count: { $sum: 1 } } },
  ],

  // Score distribution buckets
  scoreDistribution: [
    { $match: { suspended: false } },
    { $bucket: {
      groupBy: "$trustScore",
      boundaries: [0, 60, 75, 90, 101],
      default: "Unknown",
      output: { count: { $sum: 1 }, users: { $push: "$username" } },
    }},
  ],

  // Top 10 most trusted users
  topTrusted: [
    { $match: { suspended: false, "reviews.1": { $exists: true } } },
    { $sort: { trustScore: -1 } },
    { $limit: 10 },
    { $project: { name:1, username:1, trustScore:1, occupation:1, verified:1, badges:1 } },
  ],

  // Monthly new registrations
  monthlySignups: [
    { $group: {
      _id: { year: { $year: "$createdAt" }, month: { $month: "$createdAt" } },
      count: { $sum: 1 },
    }},
    { $sort: { "_id.year": 1, "_id.month": 1 } },
  ],
};

module.exports = { createIndexes, seed, pipelines, seedUsers };

// Run seed if called directly: node database/schema.js seed
if (require.main === module) {
  const arg = process.argv[2];
  if (arg === "seed") seed().catch(console.error);
  else console.log("Usage: node schema.js seed");
}
